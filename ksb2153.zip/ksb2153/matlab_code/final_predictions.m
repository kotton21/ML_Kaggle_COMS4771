function final_predictions(DATAFILE, QUIZFILE, OUTPUTFILE)
% Author: Karl Bayer
% Date: 5/3/2016
% Example Usage: 
%   final_predictions('data.csv','quiz.csv','out.csv')


% load the data
disp('loading data')
data = importfile(DATAFILE,2,inf);
quiz = importfile(QUIZFILE,2,inf);
quiz = quiz(:,1:end-1);

%randomized data
dat = [table(rand(size(data,1),1)),data];
dat = sortrows(dat,1);
labl = dat(:,end);
dat = dat(:,2:end-1);

% fit tree predictor
disp('fitting')
tree = fitctree(dat,labl);
mdl = fitcknn(dat,labl,'NumNeighbors',3,'CategoricalPredictors','all');
Ensemble = fitensemble(dat,labl,'RobustBoost',100,'Tree'); 

% predict
disp('predicting')
out_quiz_tree = predict(tree,quiz);
out_quiz_knn = predict(mdl,quiz);
out_quiz_boost = predict(Ensemble,quiz);

% output
disp('compare and output')
out_quiz_all = [out_quiz_tree,out_quiz_knn,out_quiz_boost];
out_quiz_all_mode = [out_quiz_all,mode(out_quiz_all,2)];
prediction = out_quiz_all_mode(:,4);

% write to file
inds = [1:size(prediction,1)]';
TABL = table(inds,prediction);
writetable(TABL,OUTPUTFILE);

end
